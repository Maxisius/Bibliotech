const D=864e5,T0=new Date().setHours(0,0,0,0),$=s=>document.querySelector(s);
const fmt=t=>new Date(t).toLocaleDateString('es-CO',{day:'2-digit',month:'short',year:'numeric'});
const money=n=>'$'+n.toLocaleString('es-CO')+' COP';
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function seed(){
 const bk=[["Ingeniería de Software","Roger Pressman","Ingeniería",3],["Clean Code","Robert C. Martin","Programación",2],["Cálculo de una variable","James Stewart","Matemáticas",4],["Álgebra lineal","David Lay","Matemáticas",2],["Física universitaria","Sears y Zemansky","Física",2],["Java: cómo programar","Paul Deitel","Programación",3],["Python para todos","Charles Severance","Programación",2],["Redes de computadoras","Andrew Tanenbaum","Redes",1],["Fundamentos de bases de datos","Silberschatz","Datos",2],["Introduction to the TSP","Watts Humphrey","Ingeniería",1]];
 const L=(b,u,o,d,r)=>({id:Math.random(),b,u,out:T0+o*D,due:T0+d*D,ren:0,ret:r?T0+r*D:null,fine:0,paid:false});
 return{users:[
  {n:"Nicolás Blanco",e:"nicolas@umb.edu.co",p:"1234",r:"est"},{n:"Juan Pablo Áviles",e:"juan@umb.edu.co",p:"1234",r:"est"},{n:"Ana Torres",e:"ana@umb.edu.co",p:"1234",r:"est"},
  {n:"Laura Gómez (Biblioteca)",e:"biblio@umb.edu.co",p:"1234",r:"bib"},{n:"Admin TI",e:"admin@umb.edu.co",p:"1234",r:"adm"}],
  books:bk.map((x,i)=>({id:i+1,t:x[0],a:x[1],c:x[2],tot:x[3]})),
  loans:[L(2,"nicolas@umb.edu.co",-5,2),L(6,"nicolas@umb.edu.co",-11,-4),L(1,"nicolas@umb.edu.co",-30,-23,-22),
   L(5,"juan@umb.edu.co",-3,4),L(5,"ana@umb.edu.co",-2,5),L(3,"ana@umb.edu.co",-6,1),L(8,"juan@umb.edu.co",-9,-2)],
  res:[{id:1,b:5,u:"nicolas@umb.edu.co",at:T0}],me:null}}
let S;try{S=JSON.parse(localStorage.getItem('bt2'))}catch(e){}
if(!S||!S.users)S=seed();
const save=()=>{try{localStorage.setItem('bt2',JSON.stringify(S))}catch(e){}};
let me=S.me,tab='pr',q='',cat='Todas';
const U=e=>S.users.find(u=>u.e===e),B=id=>S.books.find(b=>b.id===id);
const act=b=>S.loans.filter(l=>!l.ret&&l.b===b).length,av=b=>B(b).tot-act(b);
const mine=u=>S.loans.filter(l=>l.u===u&&!l.ret),od=l=>!l.ret&&l.due<T0;
const fine=l=>od(l)?Math.round((T0-l.due)/D)*500:(l.ret&&l.fine>0&&!l.paid?l.fine:0);
const debt=u=>S.loans.filter(l=>l.u===u).reduce((s,l)=>s+fine(l),0);
const color=id=>`hsl(${id*47%360} 45% 42%)`;
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.remove('hide');clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.add('hide'),2800)};
function lend(b,u){
 if(av(b)<1)return'No hay ejemplares disponibles.';
 if(mine(u).length>=3)return'Se alcanzó el límite de 3 préstamos activos.';
 if(mine(u).some(od))return'Hay préstamos vencidos. Devuélvelos primero.';
 if(debt(u)>0)return'Hay multas pendientes. Págalas para pedir nuevos libros.';
 S.loans.push({id:Math.random(),b,u,out:T0,due:T0+7*D,ren:0,ret:null,fine:0,paid:false});
 S.res=S.res.filter(r=>!(r.b===b&&r.u===u));save();return null}
function renew(id){const l=S.loans.find(x=>x.id==id);
 if(od(l))return'No se puede renovar un préstamo vencido.';
 if(l.ren>=2)return'Máximo 2 renovaciones por préstamo.';
 if(S.res.some(r=>r.b===l.b&&r.u!==l.u))return'Otro usuario tiene reservado este libro.';
 l.due+=7*D;l.ren++;save();return null}
function giveBack(id){const l=S.loans.find(x=>x.id==id);const f=Math.max(0,Math.round((T0-l.due)/D))*500;l.ret=T0;l.fine=f;l.paid=false;save();return f}
function notes(){if(!me)return[];const u=me.e,n=[];
 mine(u).forEach(l=>{const d=Math.round((l.due-T0)/D),t=B(l.b).t;
  if(d<0)n.push(['er',`“${t}” venció hace ${-d} día(s). Multa acumulada: ${money(fine(l))}.`]);
  else if(d<=3)n.push(['wa',`“${t}” vence ${d===0?'hoy':'en '+d+' día(s)'} (${fmt(l.due)}).`])});
 S.res.filter(r=>r.u===u&&av(r.b)>0).forEach(r=>n.push(['ok',`“${B(r.b).t}” ya está disponible para ti.`]));return n}
function vLogin(){return`<div class="card login"><h1>Ingresa a BiblioTech</h1><p class="mu">Usa tu correo institucional UMB.</p>
<form id="fl"><label for="e">Correo</label><input id="e" type="email" required autocomplete="username"><label for="p">Contraseña</label><input id="p" type="password" required autocomplete="current-password">
<p id="err" class="er hide"></p><div class="row" style="margin-top:14px"><button class="btn p">Entrar</button><button type="button" class="btn" data-a="reg">Crear cuenta</button></div></form>
<p class="mu" style="margin-top:16px">Cuentas de prueba (clave 1234):</p><div class="demo">
<button class="btn" data-a="demo" data-v="nicolas@umb.edu.co">Estudiante</button><button class="btn" data-a="demo" data-v="biblio@umb.edu.co">Bibliotecario</button><button class="btn" data-a="demo" data-v="admin@umb.edu.co">Administrador</button></div></div>`}
function vReg(){return`<div class="card login"><h1>Crear cuenta</h1><form id="fr"><label for="rn">Nombre completo</label><input id="rn" required>
<label for="re">Correo institucional</label><input id="re" type="email" pattern=".+@umb\\.edu\\.co" title="Usa un correo @umb.edu.co" required>
<label for="rp">Contraseña (mínimo 4 caracteres)</label><input id="rp" type="password" minlength="4" required><p id="err" class="er hide"></p>
<div class="row" style="margin-top:14px"><button class="btn p">Registrarme</button><button type="button" class="btn" data-a="logout">Volver</button></div></form></div>`}
function vCat(){
 const cats=['Todas',...new Set(S.books.map(b=>b.c))];
 const list=S.books.filter(b=>(cat==='Todas'||b.c===cat)&&(b.t+b.a).toLowerCase().includes(q.toLowerCase()));
 return`<h1>Catálogo</h1><div class="row" style="margin:12px 0"><input id="q" type="search" placeholder="Buscar por título o autor" value="${esc(q)}" aria-label="Buscar" style="flex:1;min-width:200px">
<select id="cat" aria-label="Categoría">${cats.map(c=>`<option ${c===cat?'selected':''}>${c}</option>`).join('')}</select></div>
<div class="grid">${list.map(b=>{const a=av(b.id);return`<article class="card book" style="--c:${color(b.id)}"><h3>${esc(b.t)}</h3><span class="mu">${esc(b.a)}</span><span class="mu">${esc(b.c)}</span>
<span class="tag ${a?'ok':'er'}">${a?a+' de '+b.tot+' disponibles':'Sin ejemplares'}</span><button class="btn" data-a="det" data-v="${b.id}">Ver detalle</button></article>`}).join('')||'<p>No hay libros con esos filtros. Prueba otra búsqueda.</p>'}</div>`}
function detail(id){const b=B(id),a=av(id),qn=S.res.filter(r=>r.b===id).length,mineR=S.res.some(r=>r.b===id&&r.u===me.e),est=me.r==='est';
 $('#dlg').innerHTML=`<h2>${esc(b.t)}</h2><p class="mu">${esc(b.a)} · ${esc(b.c)}</p><p>${a?`<span class="ok">${a} ejemplar(es) disponible(s)</span>`:'<span class="er">Sin ejemplares ahora</span>'}. ${qn?`Reservas en cola: ${qn}.`:''}</p>
<p class="mu">Préstamo de 7 días, hasta 2 renovaciones. Multa: ${money(500)} por día de retraso.</p><div class="row">
${est?(a?`<button class="btn p" data-a="lend" data-v="${id}">Pedir prestado</button>`:mineR?'<button class="btn" disabled>Ya reservaste este libro</button>':`<button class="btn p" data-a="resv" data-v="${id}">Reservar</button>`):''}
<button class="btn" data-a="close">Cerrar</button></div>`;$('#dlg').showModal()}
function loanItem(l,admin){const d=Math.round((l.due-T0)/D),b=B(l.b);
 return`<div class="item"><div><b>${esc(b.t)}</b>${admin?` <span class="mu">· ${esc(U(l.u).n)}</span>`:''}<br><span class="mu">Vence ${fmt(l.due)} · renovaciones: ${l.ren}/2</span></div>
<div class="row"><span class="tag ${d<0?'er':d<=3?'wa':'ok'}">${d<0?'Vencido '+(-d)+' d':d===0?'Vence hoy':d+' d restantes'}</span>
${admin?'':`<button class="btn" data-a="renew" data-v="${l.id}">Renovar</button>`}<button class="btn" data-a="ret" data-v="${l.id}">${admin?'Registrar devolución':'Devolver'}</button></div></div>`}
function vCuenta(){const u=me.e,ls=mine(u),h=S.loans.filter(l=>l.u===u&&l.ret),rs=S.res.filter(r=>r.u===u),dt=debt(u);
 return`<h1>Hola, ${esc(me.n.split(' ')[0])}</h1><div class="kpis"><div class="card kpi"><b>${ls.length}/3</b>préstamos activos</div><div class="card kpi"><b class="${dt?'er':''}">${money(dt)}</b>multas pendientes</div><div class="card kpi"><b>${rs.length}</b>reservas</div></div>
<h2>Préstamos activos</h2><div class="list">${ls.map(l=>loanItem(l)).join('')||'<p class="mu">No tienes préstamos. Busca un libro en el catálogo.</p>'}</div>
<h2 style="margin-top:22px">Reservas</h2><div class="list">${rs.map(r=>{const a=av(r.b);return`<div class="item"><span>${esc(B(r.b).t)}</span><div class="row"><span class="tag ${a?'ok':'wa'}">${a?'Disponible':'En espera'}</span>${a?`<button class="btn p" data-a="lend" data-v="${r.b}">Pedir prestado</button>`:''}<button class="btn d" data-a="cres" data-v="${r.id}">Cancelar</button></div></div>`}).join('')||'<p class="mu">Sin reservas.</p>'}</div>
<h2 style="margin-top:22px">Historial y multas</h2><div class="list">${h.map(l=>`<div class="item"><span>${esc(B(l.b).t)}<br><span class="mu">Devuelto ${fmt(l.ret)}</span></span>${fine(l)?`<div class="row"><span class="tag er">Multa ${money(fine(l))}</span><button class="btn" data-a="pay" data-v="${l.id}">Pagar (simulado)</button></div>`:l.fine?'<span class="tag ok">Multa pagada</span>':'<span class="tag ok">Sin multa</span>'}</div>`).join('')||'<p class="mu">Aún no hay historial.</p>'}</div>`}
function vPanel(){const adm=me.r==='adm',T=[['pr','Préstamos'],['ct','Catálogo'],...(adm?[['us','Usuarios'],['rp','Reportes']]:[])];if(!T.some(t=>t[0]===tab))tab='pr';
 let c='';
 if(tab==='pr'){const all=S.loans.filter(l=>!l.ret).sort((a,b)=>a.due-b.due),ests=S.users.filter(u=>u.r==='est');
  c=`<div class="card"><h3>Registrar préstamo</h3><form id="fp" class="row" style="margin-top:8px"><select id="pu" aria-label="Usuario">${ests.map(u=>`<option value="${u.e}">${esc(u.n)}</option>`).join('')}</select>
<select id="pb" aria-label="Libro">${S.books.map(b=>`<option value="${b.id}">${esc(b.t)} (${av(b.id)})</option>`).join('')}</select><button class="btn p">Prestar</button></form></div>
<div class="list">${all.map(l=>loanItem(l,true)).join('')||'<p class="mu">No hay préstamos activos.</p>'}</div>`}
 if(tab==='ct')c=`<div class="card"><h3>Agregar libro</h3><form id="fb" class="row" style="margin-top:8px"><input id="bt" placeholder="Título" required><input id="ba" placeholder="Autor" required><input id="bc" placeholder="Categoría" required><input id="bn" type="number" min="1" value="1" style="width:80px" aria-label="Ejemplares"><button class="btn p">Agregar</button></form></div>
<div class="list">${S.books.map(b=>`<div class="item"><span>${esc(b.t)} <span class="mu">· ${esc(b.a)}</span></span><span class="tag ${av(b.id)?'ok':'er'}">${av(b.id)}/${b.tot} disponibles</span></div>`).join('')}</div>`;
 if(tab==='us')c=`<div class="wrap"><div class="list">${S.users.map(u=>`<div class="item"><span>${esc(u.n)}<br><span class="mu">${esc(u.e)}</span></span><span><span class="tag">${{est:'Estudiante',bib:'Bibliotecario',adm:'Administrador'}[u.r]}</span> ${u.r==='est'?`<span class="mu">${mine(u.e).length} préstamos · multas ${money(debt(u.e))}</span>`:''}</span></div>`).join('')}</div></div>`;
 if(tab==='rp'){const cnt={};S.loans.forEach(l=>cnt[l.b]=(cnt[l.b]||0)+1);const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,6),mx=top[0]?top[0][1]:1;
  const a=S.loans.filter(l=>!l.ret);
  c=`<div class="kpis"><div class="card kpi"><b>${a.length}</b>préstamos activos</div><div class="card kpi"><b class="er">${a.filter(od).length}</b>vencidos</div><div class="card kpi"><b>${money(S.users.reduce((s,u)=>s+debt(u.e),0))}</b>multas pendientes</div><div class="card kpi"><b>${S.users.length}</b>usuarios</div></div>
<div class="card"><h3>Libros más prestados</h3>${top.map(([id,n])=>`<div style="margin-top:10px"><span class="mu">${esc(B(+id).t)} (${n})</span><div class="bar" style="width:${n/mx*100}%"></div></div>`).join('')}</div>`}
 return`<h1>Panel de gestión</h1><div class="tabs">${T.map(t=>`<button data-a="tab" data-v="${t[0]}" class="${t[0]===tab?'on':''}">${t[1]}</button>`).join('')}</div>${c}`}
let reg=false;
function render(){
 const hs=(location.hash||'#catalogo').slice(1);
 ['bell','out'].forEach(i=>$('#'+i).classList.toggle('hide',!me));
 if(!me){$('#nav').innerHTML='';$('#app').innerHTML=reg?vReg():vLogin();return}
 const staff=me.r!=='est',r=hs==='panel'&&staff?'panel':hs==='cuenta'&&!staff?'cuenta':'catalogo';
 $('#nav').innerHTML=`<a href="#catalogo" class="${r==='catalogo'?'on':''}">Catálogo</a>`+(staff?`<a href="#panel" class="${r==='panel'?'on':''}">Gestión</a>`:`<a href="#cuenta" class="${r==='cuenta'?'on':''}">Mi cuenta</a>`);
 $('#app').innerHTML=r==='panel'?vPanel():r==='cuenta'?vCuenta():vCat();
 const n=notes();$('#cnt').textContent=n.length?'('+n.length+')':'';
 $('#notif').innerHTML=n.length?n.map(x=>`<p class="${x[0]}" style="margin:6px 0">${x[1]}</p>`).join(''):'<p class="mu" style="margin:0">No tienes avisos nuevos.</p>';
 if(!me||me.r!=='est')$('#bell').classList.add('hide')}
function login(e){me=U(e);S.me=e;save();location.hash=me.r==='est'?'#catalogo':'#panel';render()}
document.addEventListener('click',e=>{
 const t=e.target.closest('[data-a]');if(!t){if(!e.target.closest('#notif,#bell'))$('#notif').classList.add('hide');return}
 const a=t.dataset.a,v=t.dataset.v,ch=m=>{if(m)toast(m);else render();return!m};
 if(a==='demo')login(v);
 else if(a==='reg'){reg=true;render()}
 else if(a==='logout'){me=null;S.me=null;reg=false;save();render()}
 else if(a==='det')detail(+v);
 else if(a==='close')$('#dlg').close();
 else if(a==='lend'){const m=lend(+v,me.e);$('#dlg').close();if(ch(m))toast('Préstamo registrado. Devuélvelo antes del '+fmt(T0+7*D)+'.')}
 else if(a==='resv'){S.res.push({id:Math.random(),b:+v,u:me.e,at:T0});save();$('#dlg').close();toast('Reserva creada. Te avisaremos cuando haya ejemplar.');render()}
 else if(a==='renew'){if(ch(renew(v)))toast('Renovado por 7 días.')}
 else if(a==='ret'){const f=giveBack(v);render();toast(f?'Devuelto con multa de '+money(f)+'.':'Devolución registrada.')}
 else if(a==='cres'){S.res=S.res.filter(r=>r.id!=v);save();render();toast('Reserva cancelada.')}
 else if(a==='pay'){S.loans.find(l=>l.id==v).paid=true;save();render();toast('Multa pagada.')}
 else if(a==='tab'){tab=v;render()}});
document.addEventListener('submit',e=>{e.preventDefault();const f=e.target.id,er=m=>{const p=$('#err');if(p){p.textContent=m;p.classList.remove('hide')}};
 if(f==='fl'){const u=U($('#e').value.trim().toLowerCase());if(u&&u.p===$('#p').value)login(u.e);else er('Correo o contraseña incorrectos. Revisa los datos e inténtalo de nuevo.')}
 if(f==='fr'){const m=$('#re').value.trim().toLowerCase();if(U(m))return er('Ese correo ya tiene una cuenta.');S.users.push({n:$('#rn').value.trim(),e:m,p:$('#rp').value,r:'est'});reg=false;login(m);toast('Cuenta creada. Bienvenido a BiblioTech.')}
 if(f==='fp'){const m=lend(+$('#pb').value,$('#pu').value);render();toast(m||'Préstamo registrado.')}
 if(f==='fb'){S.books.push({id:Math.max(...S.books.map(b=>b.id))+1,t:$('#bt').value,a:$('#ba').value,c:$('#bc').value,tot:+$('#bn').value});save();render();toast('Libro agregado al catálogo.')}});
document.addEventListener('input',e=>{if(e.target.id==='q'){q=e.target.value;const p=e.target.selectionStart;render();const i=$('#q');i.focus();i.setSelectionRange(p,p)}});
document.addEventListener('change',e=>{if(e.target.id==='cat'){cat=e.target.value;render()}});
$('#bell').onclick=()=>$('#notif').classList.toggle('hide');
$('#out').onclick=()=>{me=null;S.me=null;save();render()};
$('#theme').onclick=()=>{const r=document.documentElement,d=r.dataset.theme==='dark'||(!r.dataset.theme&&matchMedia('(prefers-color-scheme:dark)').matches);r.dataset.theme=d?'light':'dark'};
addEventListener('hashchange',render);
if(me&&!U(me))me=null;
render();
